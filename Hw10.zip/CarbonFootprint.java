
public interface CarbonFootprint {
   String getCarbonFootprint();
}