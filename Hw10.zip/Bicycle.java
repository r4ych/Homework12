
public class Bicycle implements CarbonFootprint {

	@Override
    public String getCarbonFootprint() {
        return "Bicycle Carbon Footprint: 0";
    }
}
